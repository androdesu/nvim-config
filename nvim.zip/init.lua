require("sethy.core")
require("sethy.lazy")
require("current-theme")
require("sethy.terminalpop")
